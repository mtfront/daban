# 大瓣 ｜ daban
你是否也曾在豆瓣写短评的时候被这个窄死人的输入框搞到崩溃？Worry no more！Meet 大瓣！！

![](/images/screenshot.png)

# 使用方法
1. 安装本 chrome 插件
2. 前往任意豆瓣条目页面
3. 点击看过/读过等标记按钮打开上图里窄死人的输入框
4. 点击右上角插件区本 chrome 插件本插件 logo 按钮

# 支持本插件
[Patreon](https://www.patreon.com/bePatron?u=46962965) | [Kofi](https://ko-fi.com/S6S130C16) | [博客](https://blog.douchi.space?utm_source=github/daban)